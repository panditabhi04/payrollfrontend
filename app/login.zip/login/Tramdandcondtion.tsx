export { default } from "./termsandconditions";
